package com.inheritance;

public class C extends B {
int i=20;
	
	void add()
	{
		System.out.println("C Add");
		//super.add();
	}
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		A c=new C();
		c.add();
		
		System.out.println("i==>");
	}
}
