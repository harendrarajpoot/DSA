package com.inheritance;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		 /*System.out.println("Stream without terminal operation");
		 Arrays.stream(new int[] { 1, 2, 3 }).map(i -> { System.out.println("doubling1 " + i); return i * 2; });
		 
		 
		 System.out.println("Stream with terminal operation"); 
			Arrays.stream(new int[] { 1, 2, 3 }).map(i -> { System.out.println("doubling " + i);//123
			 return i * 2; }).sum(); */
		
		
		int String=10; //predefind String class
		int Serializable=20; //predified Seriaiable class
		float Exception=10.2f; //predefined Exception class
		System.out.println(String);
		System.out.println(Serializable);
		System.out.println(Exception);
		
		if (true)
		{
		System.out.println("if body / true body");
		}
		System.out.println("hi rattaiah");
		
		
		
		
		
		
		
		
		
		
		}//12
	
	
}
