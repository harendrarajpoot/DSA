package com.inheritance;

public class Child extends Parent {

	void m1()
	{	
		super.m1();
		System.out.println("M1----child");
	}
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		Child p = new Child();
		//Child.m1();
	}
	
	
}
