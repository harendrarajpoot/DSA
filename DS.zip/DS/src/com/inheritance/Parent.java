package com.inheritance;

public class Parent {

	void m1()
	{
		System.out.println("M1----Parent");
	}
	
}
