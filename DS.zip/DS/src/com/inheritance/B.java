package com.inheritance;

public class B extends A {

	int i=10;
	void add()
	{
		System.out.println("B Add");
	}
}
