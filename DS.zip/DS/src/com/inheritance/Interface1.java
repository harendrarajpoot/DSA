package com.inheritance;

public interface Interface1 {

	
	void m1();
}
