package com.inheritance;

public class A {

	
	void add()
	{
		System.out.println("A Add");
	}
}
