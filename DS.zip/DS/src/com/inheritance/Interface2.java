package com.inheritance;

public interface Interface2 {

	void m1();
}
