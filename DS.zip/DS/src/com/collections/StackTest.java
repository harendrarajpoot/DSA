package com.collections;

import java.util.List;
import java.util.Stack;

public class StackTest {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		
		Stack<Integer> st=new Stack<>();
		//insert element on stack
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		System.out.println(st);
		// remove the element from the top
		st.pop();
		System.out.println(st);
		// return the top of element
		Integer peek = st.peek();
		System.out.println(peek);
		// search the element in stack
		System.out.println(st.search(10));
		// check stack empty or not
		System.out.println(st.empty());
		
		
	}
}
