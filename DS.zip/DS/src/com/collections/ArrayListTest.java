package com.collections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListTest {
public static void main(String[] args) {
	
	System.out.println("Jay Shree Krishna...");
	List<Integer> al=new ArrayList<>();
	   List<Integer> al1=new ArrayList<>();
	   al1.add(15);
	   al1.add(25);
	   al1.add(35);
	   al.add(10);
	   al.add(20);
	   al.add(30);
	   al.add(40);
	   al.add(50);
	   al.add(60);
	   al.add(70);
	   System.out.println(al);
	   // find the element of specific position
	   System.out.println(al.get(0));
	   // check element exits or not
	   System.out.println(al.contains(10));
	   // check the arraylist is empty or not 
	   System.out.println(al.isEmpty());
	   // check the size of arraylist
	   System.out.println(al.size());
	   // find the class name of List
	   System.out.println(al.getClass());
	   // convert list into array
	   Object[] array = al.toArray();
	   for(Object ob :array)
	   {
		   
		   System.out.println(ob);
	   }
	   // add element on specific position
	   al.add(1, 90);
	   System.out.println(al);
	   // add arraylist into this list
	  //al.addAll(al1);
	  //add arraylist into specific position 
	   al.addAll(1, al1);
	   System.out.println(al);
	   // remove element on specific position
	   al.remove(2);
	   System.out.println(al);
	   // remove all element from the list
	   //al.clear();
	   System.out.println(al.equals(10));
	   al.lastIndexOf(1);
	   System.out.println(al);
}
}
