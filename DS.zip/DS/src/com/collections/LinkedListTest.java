package com.collections;

import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class LinkedListTest {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		/*Queue is a FIFO(First in First out Data structure)
		 * 
		 * 
		 * 
		 * */
		Queue<Integer> list = new LinkedList<>();
		// check queue empty or not
		System.out.println(list.isEmpty());
		// add element in queue
		list.add(10);
		// add element in queue
		list.offer(20);
		list.offer(30);
		list.offer(40);
		System.out.println(list);
		//System.out.println(list.peek());
		// remove element from the queue
		//list.poll();
		//list.poll();
		
		while(!list.isEmpty())
		{
		System.out.println(list.poll());
		}
	
	}

}
