package com.collections;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueTest {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		// Priority queue is used to change the priority low to high
		//Queue<Integer>pq=new PriorityQueue<>();
		
		//change the priority high to low
		Queue<Integer>pq=new PriorityQueue<>(Collections.reverseOrder());
		pq.offer(10);
		pq.offer(300);
		pq.offer(50);
		pq.offer(40);
		
		while(!pq.isEmpty())
		{
			System.out.println(pq.poll());
		}
	}
}

