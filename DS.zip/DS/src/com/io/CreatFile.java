package com.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class CreatFile {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		
		// there are way to create file
		
		//1. Way
		
		String path="C:\\Users\\2199420\\Downloads\\newfile.txt";
		File file=new File(path);
		
		try {
			boolean flag=file.createNewFile();
			if(flag)
			{
				System.out.println("File Is Created...");
			}
			else
			{
				System.out.println("File already Present!");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// 2 Way 
		/*String filePath="C:\\Users\\2199420\\Downloads\\";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter File Name: ");
		String fileName=sc.nextLine();
		filePath+=fileName;
		System.out.println("Enter the content...");
		String content=sc.nextLine();
		
		try {
			FileOutputStream fos=new FileOutputStream(filePath);
			byte b[]=content.getBytes();
			fos.write(b);
			fos.close();
			System.out.println("File is saved on given path");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		// 3 Way using NIO library
		
		Path urlPath=Paths.get("C:\\Users\\2199420\\Downloads\\abcdf.txt");
		try {
			Path createFile = Files.createFile(urlPath);
			System.out.println("file is created--->"+createFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 4 way
		
		try {
			Path createFile = Files.createFile(Paths.get("C:\\Users\\2199420\\Downloads\\abcdf.txt"));
			System.out.println("file is cretaed --->"+createFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
