package com.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadAndWriteFileContent {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		FileInputStream in=null;
		FileOutputStream op=null;
		try {
		 in=new FileInputStream(new File("C:\\Users\\2199420\\Downloads\\2199420_Resume.docx"));
		op=new FileOutputStream(new File("C:\\Users\\2199420\\Downloads\\2199420_Resume_copy.docx"));
		
		// read file data and write into file
		
		int i=0;
		while((i=in.read())!=-1)
		{
			op.write(i);
		}
		System.out.println(in.available());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				in.close();
				op.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
