package com.io;

import java.io.File;
import java.util.Arrays;

public class PrintFileNameAndDirectory {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		String path="C:\\Users\\2199420\\Downloads";
		File file=new File(path);
		
	File files[]=file.listFiles();
	Arrays.sort(files);
	int count =1;
	for(File f:files)
	{ count++;
		if(f.isFile())
		System.out.println("FileName: "+f.getName()+" Path: "+f.getAbsolutePath());
		else if(f.isDirectory())
		System.out.println("Directory: "+f.getName()+" Path: "+f.getAbsolutePath());
	}
	
	System.out.println(count);
	}
}
