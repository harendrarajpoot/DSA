package com.io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class InputStreamReadByteData {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		
		String file="C:\\Users\\2199420\\DS\\src\\com\\io\\input.txt";
		String outfile="C:\\Users\\2199420\\DS\\src\\com\\io\\output.txt";
		try{
			// create object for read data from file
		InputStream in = new FileInputStream(file);
		
		// create object for write data into file
		OutputStream out=new FileOutputStream(outfile);
		// check is data available or not
		System.out.println(in.available());
		byte b[]=new byte[1000]; 
		in.read(b);
		String str=new String (b);
		System.out.println(str);
		
		// Converts the string into bytes
		byte ar[]=str.getBytes();
		// write data into file
		out.write(ar);

		out.close();
		in.close();
		
		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
