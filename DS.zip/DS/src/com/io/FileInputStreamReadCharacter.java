package com.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamReadCharacter {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		String file="C:\\Users\\2199420\\DS\\src\\com\\io\\input.txt";
		try {
			FileInputStream in = new FileInputStream(new File(file));
			// Reads the first byte
			int i=in.read();
			
			System.out.println(in.available());
			while(i!=-1)
			{
				System.out.print((char)i);
				// Reads next byte from the file
				i=in.read();
				
			}
			
			
			
			
			
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
