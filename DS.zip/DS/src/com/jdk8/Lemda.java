package com.jdk8;

import java.util.function.Predicate;



public class Lemda {
	/*
	 * Lemda is a anonymous function doesn't have No return type No name No
	 * modifier
	 * 
	 * Default parameter ()->{you logic multiple statement};
	 * ()->System.out.println("Only Single Statement");
	 * 
	 * 
	 * Having Parameter
	 * 
	 * (int a,int b)->{ write logic } for single statement you can also remove
	 * braces shortcut a->return a.length;
	 * 
	 * best approach (a,b)->{ }
	 * 
	 * 
	 * FOR CUSTOM OBJECT
	 *
	 * Public Double getEmpSalary(Emp emp) { Return emp.getSalary(); }
	 * 
	 * (Employee emp)->{return emp.getSalry}; (emp)->return emp.getSalary();
	 * emp->emp.getSalary();
	 * 
	 */

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		// Predicate is functional interface has only method is test is check condition return boolean value true or false
		Predicate<Integer>p=i->i>10;
		System.out.println(p.test(5));
	boolean res=p.test(20);
	System.out.println(res);
	
	System.out.println("=====================String ====================");
	
	String arr[]={"Harendra","Amit","Aman","Ajay","Bhanu","Dhananjaya"};
	
		Predicate <String>sp=(name)->name.charAt(0)=='A';
		// same line shortcut
		//Predicate <String>sp=name->name.charAt(0)=='A';
		
		for(String s:arr)
		{
			if(sp.test(s))
			{
				System.out.println(s);
			}
		}
		
	}

}
