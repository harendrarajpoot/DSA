package com.jdk8;

@FunctionalInterface
 interface Functional {
		//void m1();
		public abstract void m2();
}
/*Without Lamda Expression
 * 
public class FunctionalTest implements Functional
{
	public static void main(String[] args) {
		System.out.println("Jay shree Krishna...");
		
		FunctionalTest f=new FunctionalTest();
		f.m2();
	}

	@Override
	public void m2() {
		System.out.println("Called m2...");
		
	}
	
}
*/

public  class FunctionalTest
{
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		System.out.println("With lambda Expression....");
		
		Functional f= ()->System.out.println("With Lamda expression m2 method called");
		
		f.m2();
	}
}
