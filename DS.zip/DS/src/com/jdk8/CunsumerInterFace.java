package com.jdk8;

import java.util.function.Consumer;

public class CunsumerInterFace {

	

	
	public static void main(String[] args) {
		
	Consumer<Integer> consumer=(t)->System.out.println("hello "+t);
	consumer.accept(100);
	
	}
}
