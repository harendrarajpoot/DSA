package com.jdk8;

import java.util.ArrayList;
import java.util.stream.Stream;

public class StreamAPI {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		// there are two way to create stream 
		
		// 1st way 
		Stream<Integer> s=Stream.of(1,2,3,7,5,6,4);
		
		// Filter method filter the data from stream
		
		//s.filter(i->i>2).forEach(r->System.out.print(r+" "));
		
		//iterate the element from stream
		s.sorted().forEach((s1)->System.out.print(s1+" "));
		
		// 2nd way
		System.out.println("\n======================2nd Way to create Stream===============");
		ArrayList<Integer>al=new ArrayList<>();
		
		
		al.add(10);
		al.add(30);
		al.add(40);
		al.add(20);
		
		// create stream 
		Stream<Integer>als=al.stream();
		als.sorted().forEach((e)->System.out.print(e+" "));
		
	}
}
