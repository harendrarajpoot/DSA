package com.jdk8;

import java.util.StringJoiner;

public class StringJoinerTest {
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Radhey...");
		
		StringJoiner st=new StringJoiner(",","[","]");
		st.add("Harendra");
		st.add("Bhanu");
		st.add("Karan");
		st.add("Dhananjaya");
		
		System.out.println(st);
	}

}
