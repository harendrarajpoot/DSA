package com.convert;

public class DecimalToBinary {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		int num=100;
		int binaryNumber[]=new int[num];
		int i=0;
		int temp=num;
		while(num!=0)
		{
			binaryNumber[i]=num%2;//
			num=num/2;
			i++;
		}
		
		for (int j = i-1; j >=0; j--) {
			System.out.print(binaryNumber[j]);
		}
		
		System.out.println("\n2Nd Way");
		System.out.println(Integer.toBinaryString(temp));
	}
}
