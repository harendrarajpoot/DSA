package com.searching;

public class LinearSearch {

	public static int linearSearch(int arr[], int searchItem) {

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] == searchItem) {
				return i;
			}

		}
		return -1;

	}

	public static void main(String[] args) {

		System.out.println("Jay Shree Krishan...");
		int arr[] = { 4, 6, 7, 8, 9, 5 };
		int item = 5;
		int search = linearSearch(arr, item);

		if (search != -1)
			System.out.println(item + " Element found in position " + search);
		else
			System.out.println("Element not found...");
	}
}
