package com.eightam.ds;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class SumOfDigitUsingRecursion {

	
	public static void main(String[] args) {
		System.out.println("Jay SHree Krishana...");
		
		/*Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		System.out.println("Sum of digit of given number "+sumOfDigit(n));
		*/
		//List<Integer> list = Arrays.asList(3, 4, 1, 4, 2);
		List<Integer> list = Arrays.asList(1, 2, 3);
		System.out.println(repeatedNumber(list));
	}
	
	public static int sumOfDigit(int n)
	{
		
		if(n==0)
		return 0;
		
		return n%10+sumOfDigit(n/10);
	}
	
public static int repeatedNumber(final List<Integer> A) {
        
        int count=-1;
        
        for(int i=0;i<A.size()-1;i++)
        {
            if(A.get(i)==A.get(i))
            {
                count=A.get(i);
            }
        }
        return count;
    }
}
