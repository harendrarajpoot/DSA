package com.stack;

public class StackLinkList {

	private ListNode top;
	int length;

	private static class ListNode {
		private int data;
		private ListNode next;

		public ListNode(int data) {
			this.data = data;
			this.next = null;
		}

		@Override
		public String toString() {
			return "ListNode [data=" + data + ", next=" + next + "]";
		}

	}

	// insert elemtn
	public void push(int data) {
		ListNode newNode = new ListNode(data);
		// 20 null -->10 null
		if (isEmpty()) {
			top = newNode;
		} else {
			newNode.next = top;
			top = newNode;
		}
		length++;
	}

	// check if stack empty or not
	public boolean isEmpty() {
		return top == null;
	}

	// display all element in stack
	public void display() {
		ListNode temp = top;
		while (temp != null) {
			System.out.print(temp.data + "-->");
			temp = temp.next;
		}
		System.out.print("Null");
	}

	// 20 null -->10 null
	public void pop() {
		if (isEmpty()) {
			System.out.println("Stack is Empty");
			System.exit(1);
		}
		top = top.next;
		length--;

	}

	public int peek() {
		return top.data;
	}

	public int length() {
		return length;
	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");

		StackLinkList st = new StackLinkList();

		st.push(10);
		st.push(20);
		st.push(30);
		System.out.println("Size of Stack: " + st.length());

		st.display();

		st.pop();
		System.out.println("Size of Stack: " + st.length());
		System.out.println("\nAfter Pop");

		st.display();

		System.out.println("\nPeek: " + st.peek());
		
	}
}
