package com.stack;

public class StackArray {
	
	int arr[] = new int[10];
	int top = -1;
	int length = 0;

	public void push(int data) {
		if (isFull()) {
			System.out.println("overflow");
			System.exit(-1);
		}
		if (isEmpty()) {
			arr[++top] = data;
		} else {
			arr[++top] = data;
		}

	}
	
	public void pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack Already Empty...");
			System.exit(0);
		}
		else
		{
			--top;
		}
	}

	public void display() {
		int indx = top;
		while (indx >= 0) {
			System.out.println(arr[indx]);
			--indx;
		}
	}

	public void reverse() {
		int indx = -1;
		while (indx <= top-1) {
			++indx;
			System.out.println(arr[indx]);
			
		}
	}

	public int length() {
		return top + 1;

	}

	public void peek() {
		System.out.println(arr[top]);

	}

	public boolean isEmpty() {
		if (top == -1) {
			return true;
		}
		return false;
	}
	public boolean isFull()
	{
		return top == arr.length - 1;
	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		StackArray st = new StackArray();
		st.pop();
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(40);
		st.push(40);
		st.push(40);
		st.push(40);
		st.push(40);
		st.push(40);
		st.display();
		st.pop();
		System.out.println("after pop");
		st.display();
		st.peek();
		System.out.println("Length: " + st.length());
		st.reverse();
	}
}
