package com.stack;

import java.util.Stack;

public class ReverseStringInStack<T> {
	private ListNode<T> top;

	private static class ListNode<T> {
		T data;
		ListNode next;

		public ListNode(T data) {
			this.data = data;
			this.next=null;
		}
		
	} 

	public void push(T data) {
		ListNode<T> newNode = new ListNode<>(data);
		// 20 null -->10 null
		if (top == null) {
			
			top = newNode;
		} else {
		
			newNode.next = top;
			top = newNode;
			
		}
		
	}
	// 20 null -->10 null
	public T pop() {
		
		top=top.next;
		return top.data;
		
	}

	public String reverseString(String str) {
		ReverseStringInStack<Character> st = new ReverseStringInStack<>();
		char ch[]=str.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			st.push(ch[i]);
		}
	System.out.println(top);
		/*for( char c:ch)
		{
			System.out.println(pop());
			
		}*/
		return str;

	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		String str = "hello";
		ReverseStringInStack<Character> st = new ReverseStringInStack<>();
		st.reverseString(str);
	}
}
