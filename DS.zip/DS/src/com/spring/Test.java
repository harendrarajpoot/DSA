package com.spring;

public class Test {
	int a;
	char b;
	String c;
	byte d;
	float e;
	long f;
	short g;

	public static void main(String[] args) {
		System.out.println("Jay SHree Krishan...");
		
		Test t=new Test();
	Emp emp=new Emp();
	Add add=new Add();
	emp.emp();
	emp.fname="Harendra";
		System.out.println(emp.fname);
		System.out.println(emp.lname);
		System.out.println(emp.id);
		
		System.out.println("Default Values are........");
		
		
		for(int i=97;i<=105;i++)
		{
			System.out.println((char)t.a);
		}
		
	}
}

