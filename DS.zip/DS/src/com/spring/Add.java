package com.spring;

public class Add {
	
	int pincode;
	String state;
	String city;
	
	public void add()
	{
		System.out.println("Addres method...");
	}

}
