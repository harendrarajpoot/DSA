package com.spring;


public class Emp  
{
	
	int id;
	String fname;
	String lname;
	//
	Add address= new Add();
	

	
	public void emp()
	{
		System.out.println("Emp method..."+address);
		address.add();
	}

	
}
