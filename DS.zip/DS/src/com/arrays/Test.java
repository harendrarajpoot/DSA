package com.arrays;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

public class Test {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		Map<String ,Double> map= new HashMap<>();
		
		map.put("a", 10.0);
		map.forEach((k,v)->{System.out.println(k+""+v);});
		Set<Integer>set=new HashSet<>();
		set.add(10);
		set.add(20);
		set.add(30);
		
		set.forEach(System.out::println);
		
		//StringJoiner str=new StringJoiner("[",":","]");
		StringJoiner str=new StringJoiner(":","[","]");
		//StringJoiner str=new StringJoiner("[",":","]");
	//	StringJoiner str=new StringJoiner("[",":","]");
		str.add("p");
		str.add("q");
		System.out.println(str);
		
	}
}
