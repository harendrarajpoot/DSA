package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Create2DArrayInputFromUser {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
	Scanner sc=new Scanner(System.in);
	// create row
	System.out.println("Enter No of row.");
	int row=sc.nextInt();//2
	// create column
	System.out.println("Enter No of Col");
	int col=sc.nextInt();//3
	
	int arr[][]=new int[row][col];
	
	for(int i=0;i<row;i++)
	{
		for (int j = 0; j < col; j++) {
			arr[i][j]=sc.nextInt();
		}
	}
	//print array first way
	System.out.println("print array first way");
	for(int i=0;i<row;i++)
	{
		for (int j = 0; j < col; j++) {
			System.out.print(arr[i][j]+" ");
		}
		System.out.println();
	}
	//print array second way
	System.out.println("print array second way");
	for(int rows[]:arr)
	{
		for(int data:rows)
		{
			System.out.print(data+" ");
		}
		System.out.println();
	}
	
	//print array third way
	System.out.println("print array third way");
	
	for(int r[]:arr)
	{
		System.out.println(Arrays.toString(r));
	}
	//print array fourth using stream way
	System.out.println("print array fouth way using stream ");
	
	Arrays.stream(arr).forEach(row1->{
		Arrays.stream(row1).forEach(col1->System.out.print(col1+" "));
		System.out.println();
	});
	
	
	}
	
}
