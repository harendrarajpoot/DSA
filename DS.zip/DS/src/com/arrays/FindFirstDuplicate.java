package com.arrays;

public class FindFirstDuplicate {
	
	public static void findFirstDuplicate(int arr[])
	{
		for (int i = 0; i < arr.length; i++) {
			int temp=0;
			for (int j = i+1; j < arr.length; j++) {
				
				if (arr[i]==arr[j]) {
					System.out.println("find first Duplicate: "+arr[j]);
					temp=temp+1;
					break;
				}
			}
			if (temp>0) {
				break;
			}
		}
	}
	
	public static void main(String[] args) {
		
		System.out.println("Jay Shree Krishna...");
		int arr[]={4,6,7,3,2,7,2,8,9,3};
		findFirstDuplicate(arr);
	}

}
