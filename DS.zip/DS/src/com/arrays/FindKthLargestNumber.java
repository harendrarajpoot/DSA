package com.arrays;

public class FindKthLargestNumber {

	public static void findKthLargest(int arr[],int k)
	{
		//3,4,6,5,8,2,7,9,12,11,45
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = i+1; j < arr.length; j++) {
				
				if (arr[i]<arr[j]) {
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
			
			
			
			if (i==k-1) {
				System.out.println(k+" Largest No at :"+arr[i]);
				break;
				
			}
		}
		
		for (int j = 0; j < arr.length; j++) {
			System.out.print(arr[j]+" ");
		}
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Jay Shree Krishna...");
		int arr[]={3,4,6,5,8,2,7,9,12,11,45};
		int k=2;
		findKthLargest(arr, k);
	}
}
