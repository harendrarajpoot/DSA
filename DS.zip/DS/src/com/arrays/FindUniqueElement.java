package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class FindUniqueElement {
public static void main(String[] args) {
	System.out.println("Jay Shree Krishna...");
	
	Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int arr[]=new int [n];
    for(int i=0;i<arr.length;i++)
    {
        arr[i]=sc.nextInt();
    }
    System.out.println(Arrays.toString(arr));

    for(int i=0;i<arr.length;i++)
    {   int count=0;
        for(int j=0;j<arr.length;j++)
        {
            if(arr[i]==arr[j])
            {
                count++;
                
            }
         }
        if(count==1)
            System.out.print(arr[i]+" ");
    }
    
    
}
}
