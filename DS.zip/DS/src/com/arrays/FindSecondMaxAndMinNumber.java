package com.arrays;

import java.util.Arrays;

public class FindSecondMaxAndMinNumber {

	public static void findSecondLargestNumber(int[] arr) {
		// 4,6,7,8,9,4,7,2,3
		long start = System.nanoTime();
		Arrays.sort(arr);
		
		System.out.println(arr[arr.length - 2]);
		long end = System.nanoTime();
		System.out.println(end-start);
	}

	public static void findSecondLargestNumberSortingElement(int[] arr) {
		// 4,6,7,8,9,4,7,2,3
long start=System.nanoTime();
		
		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				if (arr[i] < arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;

				}
			}
		}
		
		
		System.out.println(arr[1]);
		System.out.println(System.nanoTime()-start);

	}

	public static int findSecondLargestNumberEfficientWay(int arr[]) {
		long start=System.nanoTime();
		//2,3,4,5,8,7,6
		int max=Integer.MIN_VALUE;
		int secondMax=Integer.MIN_VALUE;
		
		for (int i = 0; i < arr.length; i++) {
			
			if(arr[i]>max)
			{
				secondMax=max;//-233344,2,3,4,5
				max=arr[i];//2,3,4,5,8
			}
			 else if(arr[i]>secondMax && arr[i]!=max)
			{
				secondMax=arr[i];
			}
			
		}
		
		
		
			//System.out.println(System.nanoTime()-start);
			return secondMax;
	}

	public static void printArray(int arr[])
	{
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public static void main(String[] args) {

		System.out.println("jay Shree Krishna");
		int arr[] = { 4, 6, 7, 8, 9, 4, 7,12 ,2, 3 };
		findSecondLargestNumber(arr);
		findSecondLargestNumberSortingElement(arr);
		findSecondLargestNumberEfficientWay(arr);
		System.out.println("Printing Element");
		int secondMax=findSecondLargestNumberEfficientWay(arr);
		System.out.println(secondMax);
		//printArray(arr);
	}
}
