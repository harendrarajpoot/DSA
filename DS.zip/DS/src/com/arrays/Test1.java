package com.arrays;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.StringJoiner;

class Test1 
{
	
	 public static void main(String[] args) {
	StringJoiner s=new StringJoiner(":","[","]");
	StringJoiner s1=new StringJoiner(":","[","]");
	s1.add("td");
	s.add("a");
	s.add("b");
	s.add("c");
	s.merge(s1);
	System.out.println(s);
	
	LocalDate date = LocalDate.of(2019, 4, 30);
		LocalDateTime now = LocalDateTime.now();
		LocalTime localTime = LocalTime.now();
							LocalDateTime.of(date, localTime);
		
		System.out.println(localTime);
		System.out.println(now);
	System.out.println(date);
		
	
	LocalDate ofYearDay = LocalDate.ofYearDay(2020, 255);
	System.out.println(ofYearDay);
	}
}