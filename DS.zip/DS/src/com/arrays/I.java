package com.arrays;

public interface I {
	
	default void method()
	{
		System.out.println("Method Inter");
	}
}

