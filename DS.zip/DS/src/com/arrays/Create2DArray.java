package com.arrays;

import java.util.Arrays;

public class Create2DArray {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		// declare array
		int arr[][];
		
		// Instantiate Array
		arr=new int[3][3];
		
		// declare string array
		String s2Darr[][] ={{"a","b"},{"c","d"}};
		
	
			
		
		
		arr[0][0]=1;
		arr[0][1]=2;
		arr[0][2]=3;
		arr[1][0]=4;
		arr[1][1]=5;
		arr[1][2]=6;
		arr[2][0]=7;
		arr[2][1]=8;
		arr[2][2]=9;
		
		System.out.println(Arrays.deepToString(s2Darr));
		for (int i = 0; i < arr.length; i++) {
		
			for (int j = 0; j < arr.length; j++) {
				
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
}
