package com.arrays;

import java.util.Arrays;

public class FindMaxAndMinNumber {

	public static void findMinAndMax(int arr[])
	{
		//3,5,7,8,9,4,6
		int min=arr[0];
		int max=arr[0];
		for (int i = 1; i < arr.length; i++) {
			if(arr[i]<min)
			{
				min=arr[i];
			}
			if (arr[i]>max) {
				max=arr[i];
			}
			
		}
		System.out.println("Minimum Number : "+min);
		System.out.println("Maximum Number : "+max);
		
		
	}
	
	public static int recursion(int n)
	{
		if(n<0)
		{
			return -1;
		}
			
		if(n==1 || n==0)
		{
			return 1;
		}
		return (n*recursion(n-1));
	}
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int arr[]={3,5,7,8,9,4,6};
		findMinAndMax(arr);
		
		int fect=recursion(4);
		System.out.println(fect);
	}
}
