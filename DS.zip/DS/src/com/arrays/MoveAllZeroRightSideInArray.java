package com.arrays;

public class MoveAllZeroRightSideInArray {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
	}
	
	public static void moveAllZero(int arr[])
	{
		// 5,0,40,2,1,0,4
		int j=0;
		
		for (int i = 0; i < arr.length; i++) {
			if (arr[i]!=0 && arr[j]==0) {
				
			}
		}
	}
}
