package com.arrays;

import java.io.*;
import java.util.*;

public class DiamondPNCPettern {

    public static void main(String[] args) {
    
    Scanner scan=new Scanner(System.in);
        int n=scan.nextInt();
        
        for(int i=1;i<=n;i++)//4
        {
        
            for(int k=1;k<=n-i;k++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=2*i-1;j++)
            {     
                if(j==n-1 && i==n-1 )//6
                {
                System.out.print("1");
                }
                
            
                if(j==n-2 && i==n)
                {
                    System.out.print("P");
                }
                if(j==n-1 && i==n)//i 
                {
                    System.out.print("N");
                }
                if(j==n && i==n)//i 
                {
                    System.out.print("C");
                }
               else{
                System.out.print("*");
            }
             }
            System.out.println();
        }
        for(int i=1;i<=n;i++)
        {
            for(int k=1;k<=i;k++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=2*(n-i)-1;j++)
            {
                if(j==n-1 && i==1 )//6
                System.out.print("C");
            else
                System.out.print("*");
            }
            System.out.println();
        }
    
    }
}
