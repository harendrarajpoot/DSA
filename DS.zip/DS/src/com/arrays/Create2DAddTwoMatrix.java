package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Create2DAddTwoMatrix {
	
	public static void main(String[] args) {
		System.out.println("Jay shree Krishna...");
	Scanner sc=new Scanner(System.in);
	
	int row=sc.nextInt();
	int col=sc.nextInt();
	int first[][]=new int[row][col];
	int second[][]=new int[row][col];
	int sum[][]=new int[row][col];
	System.out.println("Enter First Matrix");
	for (int i = 0; i < row; i++) {
	
		for (int j = 0; j < col; j++) {
			first[i][j]=sc.nextInt();
		}
	}
	System.out.println("Enter second matrix");
	for (int i = 0; i < row; i++) {
		
		for (int j = 0; j < col; j++) {
			second[i][j]=sc.nextInt();
		}
	}
	// print first matrix
	System.out.println("Print First Matrix");
	for(int r[]:first)
	{
		System.out.println(Arrays.toString(r));
	}
	System.out.println("Print Second Matrix");
	for(int r[]:second)
	{
		System.out.println(Arrays.toString(r));
	}
	
	// sum of two matrix
	for (int i = 0; i < row; i++) {
		
		for (int j = 0; j < col; j++) {
			sum[i][j]=first[i][j]+second[i][j];
		}
	}
	
	System.out.println("Print sum of two Matrix");
	
	for(int r[]:sum)
	{
		System.out.println(Arrays.toString(r));
	}
}
	
}
