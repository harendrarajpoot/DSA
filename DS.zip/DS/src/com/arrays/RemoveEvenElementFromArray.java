package com.arrays;

public class RemoveEvenElementFromArray {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		
		int arr[]={3,4,5,6,7,8,9,10};
		// input 3,4,5,6,7,8,9,10
		// output 3,5,7,9
		printArray(arr);
		int res[]=removeEvenElement(arr);
		printArray(res);
	}
	
	
	public static int[] removeEvenElement(int arr[])
	{	
		int count=0;
		for (int i = 0; i < arr.length; i++) {
		
			if (arr[i]%2!=0) {
				count++;
			}
		}
		int result[]=new int[count];
		int index=0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i]%2!=0) {
				result[index]=arr[i];
				index++;
			}
		}
		
		return result;
		
	}
	
	public static void printArray(int arr[])
	{
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		
	}
}
