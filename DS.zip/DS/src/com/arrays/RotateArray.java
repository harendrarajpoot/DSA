package com.arrays;

import java.util.Arrays;

public class RotateArray {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int arr[]={2,3,4,5,6};
		System.out.println(Arrays.toString(arr));
		
		int last=arr[arr.length-1];
		
		for (int i = 0; i < arr.length; i++) {
			
			int temp=arr[i+1];
			arr[i+1]=arr[i];
			arr[i+2]=temp;
			
		}
		arr[0]=last;
		System.out.println(Arrays.toString(arr));
		
	}
}
