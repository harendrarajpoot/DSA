package com.arrays;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class FindDuplicate {

	// brute force algorithm
	public static void findDuplicateBruteForce(int arr[]) {
		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				if (arr[i] == arr[j] && (i != j)) {

					System.out.println("Duplicate" + arr[j] + " ");
				}

			}
		}
	}

	public static void findDuplicateHashSet(int[] arr) {
		Set<Integer> set = new HashSet<>();
		for (int n : arr) {
			if (set.add(n) == false) {
				System.out.println("duplicate " + n);
			}
		}

	}

	public static void findDuplicateByHashMap(int arr[]) {
		Map<Integer, Integer> map = new HashMap<>();

		for (int n : arr) {
			Integer count = map.get(n);
			
			if (count == null) {
				map.put(n, 1);
			}
			else
			{
				
				map.put(n,count+1);
			}
			
		}
		
		System.out.println("Duplicate elements are: ");
	Set<Map.Entry<Integer, Integer>> es=map.entrySet();
	for(Map.Entry<Integer, Integer> mp:es)
	{
		if(mp.getValue()>1)
		{
			System.out.println(mp.getKey()+" ");
		}
	}

	}

	public static void main(String[] args) {

		System.out.println("Jay Shree Krishna");

		int arr[] = { 3, 5, 4, 3, 2, 2, 1, 3 };
		findDuplicateBruteForce(arr);
		System.out.println();
		System.out.println("HashSet ");
		findDuplicateHashSet(arr);
		findDuplicateByHashMap(arr);
	}
}
