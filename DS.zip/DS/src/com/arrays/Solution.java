package com.arrays;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.Arrays;

public class Solution{

    private static int[] printColSum(int[][] matrix){
        int numRows = matrix.length;
        int numCols = matrix[0].length;
        int[] colSum = new int[numCols];
        // Loop through the given number of columns
        for(int i = 0; i < numCols; i++)
        {
            // define the sum variable to get the column sum
            int sum = 0;

            // Loop through the elements in the column
            for(int j = 0; j < numRows; j++)
                // add every element to the sum variable
                sum += matrix[j][i];
            // add the column sum to the result array
            colSum[i] = sum;
        }
        return colSum;
    }

    private static void printMatrix(int[][] matrix){
        for (int[] row : matrix)
            System.out.println(Arrays.toString(row));
    }

    public static void main(String[] args){
    	int a=-2;
    	System.out.println(a);
        int matrix[][] = {{1, 2, 3},
                {4, 5, 6},
                {7, 8 , 9}};

        printMatrix(matrix);
        System.out.println("The column sum of the above matrix is as follows:");
        int[] colSum = printColSum(matrix);
        for(int i: colSum)
            System.out.println(i);
    }
}