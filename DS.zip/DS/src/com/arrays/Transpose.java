package com.arrays;

import java.util.Arrays;

public class Transpose {

	public static void main(String[] args) {
		System.out.println("Jay Shree krishan...");

		int arr[][] = { { 1, 1, 1, 1 }, { 2, 2, 2, 2 }, { 3, 3, 3, 3 }, { 4, 4, 4, 4 } };

		for (int ar[] : arr)
			System.out.println(Arrays.toString(ar));

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				System.out.print(arr[j][i] + " ");
			}
			System.out.println();
		}

		String s="Java is computer";
		
		System.out.println(s.substring(0, 2));

	}
}
