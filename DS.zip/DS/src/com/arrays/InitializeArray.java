package com.arrays;

import java.util.Arrays;

public class InitializeArray<T> {

	
public boolean isSorted(int arr[])
{
	boolean status =true;
	
	int i=1;
	while(i<arr.length)
	{
		if(arr[i]<arr[i-1])
		{
			 status=false;
			 break;
		}
		i++;
	}
	return  status;
}
	public void display(int arr[])
	{// while loop
		int i=0;
		while(i<arr.length)
		{
			System.out.println(arr[i]);
			i=i+1;
		}
		// forloop
		/*for(int j=0;j<arr.length;j++)
		{
			System.out.println(arr[j]);
		}
		
		// for each loop
		
		for(int ar:arr)
		{
			System.out.println(ar);	
		}*/
	}
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		
		int intArr[]=new int[4];
		//float arr[] =new float[3];
		//boolean arr[]= new boolean[3];
		String stringArr[]=new String[3];
		stringArr[0]="Harendra";
		stringArr[1]="Kumar";
		stringArr[2]="Rajpoot";
		
		intArr[0]=1;
		intArr[1]=2;
		intArr[2]=3;
		intArr[3]=4;
		
		int arr[]={1,2,3,4};
		
		int len=arr.length/2;//2
		
		if(len%2!=0)
		{
			System.out.println("222222222222");
			System.out.println("Mid : "+arr[len-1] +" "+arr[len]);
		}
		else
		{
			System.out.println("Mid Element: "+arr[len]);
			
		}
		
		
		
		
		
		
		
		
		InitializeArray obj = new InitializeArray<>();
		obj.display(intArr);
		System.out.println("after clone...");
		// first way clone arr 
		//int newArray[]=intArr.clone();;
		
		// second way clone arr 
				int newArray[]=Arrays.copyOf(intArr , intArr.length);
		
		newArray[0]=20;
		System.out.println("after update");
		obj.display(intArr);
		obj.display(newArray);
		
		
		System.out.println(obj.isSorted(intArr));
		
		
		
		
		
	}
}
