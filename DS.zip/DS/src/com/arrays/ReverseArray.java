package com.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReverseArray {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		int arr[]={2,3,4};
		List<Integer> list = new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		//printArray(arr);
		list.add(30);
		list.add(40);
		//reverseArray(arr);
		//System.out.println("After Reverse");
		//printArray(arr);
		reverseList(list);
	}
	
	public static void reverseArray(int arr[])
	{// 1,2,3
		//int result[]=new int[arr.length];
		
		int start=0,end=arr.length-1;
		while(start<end)
		{
			int temp=arr[end];
			arr[end]= arr[start];
			arr[start]=temp;
			start++;
			end--;
		}
		
		
	}
	public static void printArray(int arr[])
	{
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	
	public static void reverseList(List<Integer> a)
	{
	
		System.out.println(Math.abs(2));
	    
	    int start=0,end=a.size()-1;
		while(start<end)
		{
			int temp=a.get(end);
			a.set(end, a.get(start));
			a.set(start,temp);
			start++;
			end--;
		}
	    System.out.println(a);
	}    
	  
}
