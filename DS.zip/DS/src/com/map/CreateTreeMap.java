package com.map;

import java.util.TreeMap;

public class CreateTreeMap {

	public static boolean checkPurple(String str[])
	{
		

		String target ="purple";
		//p,u,p,l,e,r,p,e,l,e
		
		for(String s:str)
		{
			
			System.out.print(s+"");
			String[] split = s.split(" ");
			
			//for(String ch:split)
			
		}
		
		char ch[]=target.toCharArray();
		//String sl[]=str.split(" ");
		
		for(int i=0;i<ch.length;i++)
		{
			/*for(int j=0;j<str[i].split(" ");j++)
			{
				System.out.print(str[j]+" ");
			}*/
			
		}
		return false;
	}
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		
		String[]str={"p","u","ple","rp","e","le"};
		
		System.out.println(checkPurple(str));
		
		
		
		
		// tree map maintain sorted order
		// does not have null key
		TreeMap<Integer,String> map = new TreeMap<>();
		TreeMap<Integer,String> treeMap = new TreeMap<>();
		map.put(1, "harendra");
		map.put(5, "karan");
		map.put(3, "Dhananjaya");
		map.put(2, "Bhanu");
		map.put(4, "Prince");
		map.put(4, null);
		System.out.println(map);
		
		
	}
}
