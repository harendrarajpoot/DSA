package com.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class CreateHashMap {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan..");
		
		Map<Integer,String> map= new HashMap<>();
		
		map.put(1, "harendra");
		map.put(2, "Bhanu");
		map.put(4, "Prince");
		map.put(3, "Dhananjaya");
		map.put(5, "karan");
		
		/*for(int i=1;i<=20;i++)
		{
			map.put(i+6, "Harnedra"+i);
		}
		*/
		System.out.println(map);
// get value
		System.out.println(map.get(3));
		
		// get all keys
	System.out.println("Keys------>"+map.keySet());
	// get all values
	System.out.println("Values----->"+map.values());
	// iterate all key and values
	
	// 1 Approach
	Set<Entry<Integer,String>>set=map.entrySet();
	Iterator<Entry<Integer,String>>itr=set.iterator();
	//Iterator<Entry<Integer, String>> iterator = set.iterator();
	while(itr.hasNext())
	{
		//System.out.println(itr.next());
		Entry<Integer, String> entry = itr.next();
		System.out.println(entry.getKey()+"-->"+entry.getValue());
		
	}
	//2 Approach
	System.out.println("second approach");
	Set<Integer>key=map.keySet();
	for(Integer k:key)
	{
		System.out.println(k+"-->"+map.get(k));
	}
		
	}
}
