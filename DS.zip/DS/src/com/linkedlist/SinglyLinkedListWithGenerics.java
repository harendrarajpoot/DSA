package com.linkedlist;

import java.util.LinkedList;

public class SinglyLinkedListWithGenerics<T> {
	
	private Node<T> head;
	private static class Node<T> {
		private T data;
		Node<T> next;

		public Node(T data) {
			this.data = data;
			this.next = null;
		}

		@Override
		public String toString() {
			return "Node [data=" + data + ", next=" + next + "]";
		}
		

	}
	public boolean isEmpty()
	{
		if(head==null)
		{
			return true;
		}
		return false;
	}
	public void display()
	{
		Node<T> temp=head;
		while (temp!=null) {
			System.out.print(temp.data+"--->");
			temp=temp.next;
		}
		System.out.println("Null");
	}
	
	public void addElementAtBeginning(T data)
	{
	Node<T>node=new Node<>(data);// 
	node.next=head;//30 null-->20 null--->10 null 
	head=node;// 10 and Reference
	}

	
	public void addElementAtLast(T data)
	{
		Node<T> node=new Node<T>(data);
		if(head==null)
		{
			head=node;
			return;
		}
		Node<T> temp=head;// Head--800-->30 1000-->20 1200--->10 null 
		while(temp.next!=null)
		{
			temp=temp.next;
		}
		temp.next=node;
	}
	
	public void addElementAtGivenPosition(T data,int pos)
	{
		/*30 null-->20 null--->10 null
		 * 40 null 
		 * pos =2
		 * 
		 * 
		 * 
		 * */
		Node<T> node=new Node<T>(data);
		if(pos<=0)
		{
			throw new IllegalArgumentException("Invalid Position");
		}
		if(pos==1)
		{
			node.next = head;
			head = node;
			return;
		}
		
		Node<T> currentNode=head;// 
		
		for (int i = 1; i < pos; i++) {
			 currentNode = currentNode.next;
			if (currentNode == null) {
				throw new IllegalArgumentException("Out Of Range... ");
			}
		}
		node.next = currentNode.next;
		currentNode.next = node;
	}
	
	public Node<T> deleteFirstNode()
	{
		if(head==null)
		{
			return null;
		}
		Node<T> temp=head;
		head=temp.next;
		temp.next=null;
		return temp;
	}
	
	public Node<T> deleteLastNode()
	{
		if(head==null || head.next==null)
		{
			return head;
		}
		Node<T> current=head;//30 null-->20 null--->10 null
		Node<T> pre=null;
		while(current.next!=null)
		{
			pre=current;
			current=current.next;
			
		}
		pre.next=null;
		
		return current;
	}
	public void deleteNodeGivenPosition(int pos)
	{
		if(pos==1)
		{
			head=head.next;
		}
		else
		{
			Node<T> previous=head;//30 null-->20 null--->10 null
			int count=1;
			while(count<pos)
			{
				previous=previous.next;
				count++;
			}
			Node<T> current=previous.next;
			previous.next=current.next;
		}
		
		
		
	}
	
	public boolean searchElement(T key)
	{
		Node<T> temp=head;
		
		System.out.println();
		while(temp!=null)
		{
			if(temp.data==key)
			{
				return true;
			}
		temp=temp.next;
		}
		return false;
	}
	
	public static void main(String[] args) {

	new LinkedList<>();
		System.out.println("Jay Shree Krishan...");
		
		SinglyLinkedListWithGenerics<Integer> sll=new SinglyLinkedListWithGenerics<>();
		System.out.println(sll.isEmpty());
		sll.addElementAtBeginning(10);
		sll.addElementAtBeginning(20);
		//sll.addElementAtBeginning(30);
		System.out.println(sll.head);
		sll.display();
		sll.addElementAtLast(40);
		sll.addElementAtLast(50);
		System.out.println(sll.isEmpty());
		sll.display();
		sll.addElementAtGivenPosition(60, 2);
		sll.display();
		
		//sll.deleteFirstNode();
		sll.deleteFirstNode();
		sll.display();
		System.out.println(sll.searchElement(10));
		sll.deleteLastNode();
		sll.display();
		sll.deleteNodeGivenPosition(2);
		sll.display();
	}
}
