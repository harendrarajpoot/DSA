package com.linkedlist;

public class SinglyLinkListRepresentation {

	private static class ListNode
	{
		private int data;
		private ListNode next;
		
		public ListNode(int data) {
			this.data=data;
		}

		@Override
		public String toString() {
			return "ListNode [data=" + data + ", next=" + next + "]";
		}
		
	}
	
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		// create Node
		ListNode a=new ListNode(20);
		ListNode b=new ListNode(30);
		ListNode c=new ListNode(40);
		ListNode d=new ListNode(50);
		ListNode e=new ListNode(60);
	
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		
		// connect node to each other
		
		a.next=b;
		b.next=c;
		c.next=d;
		d.next=e;
		
		System.out.println("After Connect ...");
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		
		// display all elements
		
		ListNode temp=a;
		while(temp!=null)
		{
			System.out.print(temp.data+"-->");
			temp=temp.next;
		}
		System.out.println("NULL");
		

		
		
		
	}
}
