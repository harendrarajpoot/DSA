package com.linkedlist;

public class SinglyLinkedList {

	private ListNode head;

	private static class ListNode {
		private int data;
		private ListNode next;

		public ListNode(int data) {
			this.data = data;
		}

		@Override
		public String toString() {
			return "ListNode [data=" + data + ", next=" + next + "]";
		}

	}

	// check list is empty or not
	public boolean isEmpty() {
		return head == null;
	}

	public int size() {
		int length = 0;
		if (head == null) {
			return length;
		}

		ListNode temp = head;
		while (temp != null) {
			length++;
			temp = temp.next;
		}
		return length;
	}

	// insert element at first position

	public void addFirst(int data) {
		ListNode newNode = new ListNode(data);
		// 30 NUll <--20 Null
		if (isEmpty()) {
			head = newNode;
		} else {
			newNode.next = head;
			head = newNode;
		}
	}

	// display All elements

	public void display() {
		ListNode temp = head;
		while (temp != null) {
			System.out.print(temp.data + "-->");
			temp = temp.next;
		}
		System.out.println("Null");
	}
	public void display(ListNode head) {
		ListNode temp = head;
		while (temp != null) {
			System.out.print(temp.data + "-->");
			temp = temp.next;
		}
		System.out.println("Null");
	}

	public void addLast(int data) {
		ListNode newNode = new ListNode(data);
		// 20 Null--> 30 NUll
		if (isEmpty()) {
			head = newNode;
		} else {
			// 20 null--> 30 null--> 40 null
			ListNode temp = head;
			while (temp.next != null) {
				temp = temp.next;

			}
			temp.next = newNode;

		}

	}

	public void addGivenPosition(int data, int pos) {

		ListNode newNode = new ListNode(data);
		if (pos < 1) {
			System.out.println("invalid Position");
		} else if (pos == 1) {
			newNode.next = head;
			head = newNode;
		} else {
			ListNode temp = head;
			// 12 null-->20 null --> 14 null--> 30 null-->40 null--> 50 null
			// 12 null-->12 null-->20 null --> 14 null--> 30 null-->40 null-->
			// 50 null
			for (int i = 1; i < pos - 1; i++) {
				temp = temp.next;
			}
			newNode.next = temp.next;
			temp.next = newNode;

		}

	}

	// 12 null-->20 null --> 14 null--> 30 null-->40 null--> 50 null
	public ListNode removeFirst() {
		if (isEmpty()) {
			return head;
		}
		ListNode temp = head;
		head = temp.next;
		temp.next = null;
		return temp;
	}

	// remove last
	public ListNode removeLast() {
		if (isEmpty()) {
			return head;
		}
		// 30 null-->40 null--> 50 null
		ListNode temp = head;
		ListNode previous = null;
		while (temp.next != null) {
			previous = temp;
			temp = temp.next;
		}
		previous.next = null;
		return temp;
	}

	// 30 null-->40 null--> 50 null --> 60 null
	public void removeGivenPosition(int pos) {

		if (pos < 1 || pos > size()) {
			System.out.println("invalid Position");
		}

		else if (pos == 1) {
			head = head.next;
		} else {
			ListNode temp = head;
			int count = 1;
			while (count < pos - 1) {
				temp = temp.next;
				count++;
			}
			ListNode previous = temp.next;
			temp.next = previous.next;

		}

	}

	public ListNode reverse() {
		ListNode current = head;
		ListNode next = null;
		ListNode previous = null;
		while (current != null) {
			next = current.next;
			current.next = previous;
			previous = current;
			current = next;

		}
		
		return previous;

	}
	
	public int findMidElement()
	{
		ListNode slowPtr=head;
		ListNode fastPtr=head;
		
		while(fastPtr!=null && fastPtr.next!=null)
		{
			slowPtr=slowPtr.next;
			fastPtr=fastPtr.next.next;
		}
		
		return slowPtr.data; 
	}

	public boolean searchElement(int key) {
		ListNode temp = head;
		while (temp != null) {
			if (key == temp.data) {
				return true;
			}
			temp = temp.next;
		}
		return false;

	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		SinglyLinkedList sll = new SinglyLinkedList();
		sll.addFirst(10);
		sll.addFirst(20);
		sll.addFirst(30);

		sll.addLast(40);
		sll.addLast(50);
		//sll.addLast(60);

		sll.display();
/*
		System.out.println(sll.searchElement(16));
		sll.addGivenPosition(14, 7);
		sll.display();
		sll.removeFirst();
		sll.display();
		sll.removeLast();
		sll.display();
		sll.removeGivenPosition(3);
		sll.display();
		System.out.println("BEfore reverse ===>");
		sll.display();
		System.out.println("Reverse=========");
		ListNode reverse = sll.reverse();
		sll.display(reverse);*/
		
		System.out.println(sll.findMidElement());
		

	}
}
