package com.linkedlist;

public class DoublyLinkList {

	private ListNode head;
	private ListNode tail;
	private int length;
	
	// constractor assign default values
	public DoublyLinkList() {
		this.head=null;
		this.tail=null;
		this.length=0;
	}
	
	// create doubly linklist
	private static class ListNode {
		private int data;
		private ListNode next;
		private ListNode previous;

		public ListNode(int data) {
			this.data = data;
		}

		@Override
		public String toString() {
			return "ListNode [data=" + data + ", next=" + next + ", previous=" + previous + "]";
		}
		
	}
	
	// check linklist is empty or not
	public boolean isEmpty()
	{
		return length==0;
	}

	public void insertLast(int data)
	{
		ListNode node=new ListNode(data);
		if(isEmpty())
		{
			head=node;
		}
		else
		{
			tail.next=node;
		}
		node.previous=tail;
		tail=node;
		length++;
	}
	
	public void displayForward()
	{
		if(head==null)
		{
			return;
		}
		ListNode temp=head;
		
		while(temp!=null)
		{
			System.out.print(temp.data+"->");
			temp=temp.next;
		}
		System.out.print("Null");
	}
	public void displayBackward()
	{
		if(tail==null)
		{
			return;
		}
		ListNode temp=tail;
		
		while(temp!=null)
		{
			System.out.print(temp.data+"->");
			temp=temp.previous;
		}
		System.out.print("Null");
	}
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		DoublyLinkList dll = new DoublyLinkList();
		System.out.println(dll.head);
		dll.insertLast(10);
		System.out.println(dll.head);
		System.out.println(dll.tail);
		dll.insertLast(20);
		dll.displayForward();
		System.out.println();
		dll.displayBackward();
		 
	}
}
