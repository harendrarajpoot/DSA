package com.linkedlist;

import java.io.*;
import java.util.*;

public class Solution {
    private static ListNode head;
    private static class ListNode 
    {
        private int data;
        private ListNode next=null;
        
        ListNode(int data)
        {
            this.data=data;
            this.next=null;
        }
    }
    
    public  static void addLast(int data)
    {
        ListNode newNode=new ListNode(data);
        
        if(head==null)
        {
            head=newNode;
        } 
        else
        {
            ListNode temp=head;
            
            while(temp.next!=null)
            {
                temp=temp.next;
            }
            temp.next=newNode;
        }
    }
    
    public  static void display()
    {
        ListNode temp=head;
        while(temp!=null)
        {
            System.out.print(temp.data+"->");
            temp=temp.next;
        }
        System.out.print("Null");
    }

    public static boolean checkPurple(String str[])
	{
    	for(int i=0;i<str.length;i++)
    	{
    		for(int j=0;j<str[i].length();j++)
    		{
    			System.out.println(str[i].charAt(i)+",");
    		}
    		//System.out.print(str[i]+" ");
    	}
    	
    	return false;
	}
    public static void main(String[] args) {
    
    	String[]str={"p","u","ple","rp","e","le"};
    	System.out.println(checkPurple(str));
    	
    	/* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
    /*Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int i=1;i<=n;i++)

        {    
            addLast(sc.nextInt());
        }
    
        display();*/
     //   Hashtable<K, V>
    }
}
