package com.sorting;

import java.util.Arrays;

public class BubbleSort {

	public static void bubblesort(int arr[]) {
		int temp = 0;
		
		for (int j = 0; j < arr.length; j++) {// 0
			boolean flag = true;
			for (int i = 0; i < arr.length - 1; i++) {// 0,1
				if (arr[i] > arr[i + 1]) {
					temp = arr[i];
					arr[i] = arr[i + 1];
					arr[i + 1] = temp;
					flag = false;
				}
			}

			if (flag) {
				break;
			}

		}

	}

	public static void main(String[] args) {

		System.out.println("Jay Shree Krishna...");

		int arr[] = { 4, 2, 6, 3, 8 };
		System.out.println(Arrays.toString(arr));
		bubblesort(arr);
		System.out.println(Arrays.toString(arr));

	}
}
