package com.sorting;

import java.util.Arrays;

public class SelectionSort {

	public static void selectionSorting(int[] arr) {
		//30, 12, 15, 18, 6 
		for(int i=0;i<arr.length;i++)// arr.length-1 no need to swap last element
		{
			int min=i;
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[j]<arr[min])
				{
					min=j;
				}	
			}
			int temp=arr[i];
			arr[i]=arr[min];
			arr[min]=temp;
		}
		
		
	}
	

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna");
		int arr[] = { 30, 12, 15, 18, 6 };
		System.out.println(Arrays.toString(arr));
		selectionSorting(arr);
		System.out.println(Arrays.toString(arr));
		
	}
}
