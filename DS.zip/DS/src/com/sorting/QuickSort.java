package com.sorting;

import java.util.Arrays;

public class QuickSort {

	public void quickSortRecursion(int[] arr, int low, int high) {

		int pi = partition(arr, low, high);
		if (low < pi-1) {
			quickSortRecursion(arr, low, pi - 1);
		}
		

		if(pi<high)
		{
			quickSortRecursion(arr, pi, high);
		}

	}
	// 15,9,7,13,12,16,4,18,11

	public int partition(int[] arr, int low, int high) {
		int pivot = arr[(low+high)/2];

		while (low<high) {

			while (arr[low] < pivot) {
				low++;
			}
			while (arr[high] > pivot) {
				high--;
			}

			if (low <=high) {
				int temp = arr[high];
				arr[high] = arr[low];
				arr[low] = temp;
				low++;
				high--;
			}

		}
		//System.out.println("Low--->"+low);

		return low;

	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");

		int arr[] = { 15, 9, 7, 13, 12, 16, 4, 18, 11 };

		System.out.println(Arrays.toString(arr));
		QuickSort qs = new QuickSort();
		//qs.partition(arr, 0, arr.length - 1);
		 qs.quickSortRecursion(arr, 0, arr.length-1);
		System.out.println(Arrays.toString(arr));
	}
}
