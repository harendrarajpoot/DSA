package com.basic;

public class SwapTwoNumber {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		findSwapTwoNumber(10, 20);
	}
	
	public static int findSwapTwoNumber(int a,int b)
	{
		System.out.println("Before Swap:"+a+":"+b);
		int temp=b;
		b=a;
		a=temp;
		System.out.println("after Swap:"+a+":"+b);
		return 0;
	}
}
