package com.basic;

public class CalculatePower {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int res=findPower(2, 3);
		System.out.println(res);
	}
	
	public static int findPower(int num,int power)
	{
		int res=1;
		
		if((num==0&&power>=1)|| power<=0)
		{
			return 0;
		}
		//2^3=8
		for (int i = 1; i <=power; i++) {
			res=res*num;
		}
		
		
		return res;
	}
}
