package com.basic;

public class FindAreaOfRectangle {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int res=findAreaOfRectangle(5,2);
		System.out.println(res);
	}
	
	public static int findAreaOfRectangle(int breath,int height)
	{
		//Area of Rectangle = (breath*height)
		return height*breath; 
	}
}
