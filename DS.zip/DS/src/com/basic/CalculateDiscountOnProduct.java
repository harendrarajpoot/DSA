package com.basic;

public class CalculateDiscountOnProduct {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int res=findDiscount(50, 12);
		System.out.println(res);
	}
	
	public static int findDiscount(int price,int dis)
	{
		int discount=(price*dis)/100;
		return (price-discount);
	}
}
