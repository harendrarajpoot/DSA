package com.basic;

public class FindAvgOfNNumber {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int arr[]={10,20,30,40,50};
		int res=findAvgOfNumer(arr);
		System.out.println(res);
	}
	
	public static int findAvgOfNumer(int arr[])
	{
		int result=0;
		for (int i = 0; i < arr.length; i++) {
			 result=(result+arr[i]);
		}
		return result/arr.length;
		
	}
}
