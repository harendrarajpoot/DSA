package com.basic;

public class DecimalToBinary {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		 int a = 5;
	     int b = 7;
	 
	 System.out.println(a>b);
	     
	}
}
