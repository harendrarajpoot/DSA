package com.basic;

public class FindFectorial {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int res=findFectorial(5);
		System.out.println(res);
	}
	
	public static int findFectorial(int num)
	{
		int fect=1;
		for (int i = 1; i <=num; i++) {
			fect=i*fect;
		}
		return fect;
	}
}
