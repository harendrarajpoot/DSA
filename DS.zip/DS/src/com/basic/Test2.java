package com.basic;

 class Test
{
	
	 public static void method2()
	 {
		 System.out.println("Method2222222");
	 }
}
 

 public class Test2
 {
	 // instance variable
	 String name; // non static
	 public static void method()
	 {
		 System.out.println("Method11");
		 
	 }
	public static void main(String[] args) {
		
		//Test2 t=new Test2();
		method();
		Test2.method();
		Test.method2();
	}
	
}