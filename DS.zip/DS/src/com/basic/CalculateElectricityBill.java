package com.basic;

public class CalculateElectricityBill {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		int pay=findElectricityBill(280);
		System.out.println(pay);
	}
	
	public static int findElectricityBill(int units)
	{
		
		
		return 0;
	}
}
