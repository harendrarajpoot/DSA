package com.basic;

public class FindHCF {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
	int result=	findHcf(45, 15);
	System.out.println(result);
	}
	
	public static int findHcf(int num1,int num2)
	{
		int temp;
		if(num2<=0)
		{
			return 0;
		}
		//35,15
		while(num2>0)
		{
			temp=num2;//15,5
			num2=num1%num2;//5,0
			num1=temp;//15,5
		}
		return num1;
		
	}
}
