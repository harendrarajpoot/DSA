package com.basic;

public class FindLargestAmongThreeNumber {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		int result = findLargestAmongThreeNumber(100, 50, 40);
		System.out.println(result);
	}

	public static int findLargestAmongThreeNumber(int a, int b, int c) {
		if (a > b && a > c) {
			return a;
		} else if (b > c && b > a) {
			return b;

		} else {
			return c;
		}
	}
}
