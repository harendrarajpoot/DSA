package com.basic;

public class ReverseNumber {

	public static void main(String[] args) {
		System.out.println("Jay Shree Shree Krishan...");
		int result=findReverseNumber(45);
		System.out.println(result);
	}
	public static int findReverseNumber(int num)
	{
		int rev=0;
		while(num!=0)
		{//450
			rev=rev*10+num%10;
			num=num/10;
			
		}
		return rev;
	}
}
