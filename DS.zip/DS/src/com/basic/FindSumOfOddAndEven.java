package com.basic;

public class FindSumOfOddAndEven {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int arr[]={1,2,3,4,5,6};
		findSumOfDigitOddAndEven(arr);
	}
	
	public static int findSumOfDigitOddAndEven(int arr[])
	{
		int odd=0,even=0;
		for (int i = 0; i < arr.length; i++) {
			
			if (arr[i]%2==0) {
				
				even=even+arr[i];
				
			}
			else
			{
				odd=odd+arr[i];
			}
			
		}
		System.out.println("sum of Odd: "+odd);
		System.out.println("sum of even: "+even);
		
		return 0;
	}
}
