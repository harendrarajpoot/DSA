package com.basic;

public class FindAreaOfCircle {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		
		int area=findAreaOfCircle(7);
		System.out.println(area);
	}
	
	public static int findAreaOfCircle(int r)
	{// Area of Circle=πr^2--> π=22/7;
		return (22*r*r)/7;
	}
}
