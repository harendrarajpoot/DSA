package com.basic;

public class ArmstrongNumber {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int n=153;
		int temp=n;
		int sum=0;
		while(n!=0)
		{
			int rem=n%10;//1
			sum=sum+(rem*rem*rem);//1+125+27
			n=n/10;
		}
		if(sum==temp)
		{
			System.out.println("Its Armstrong");
		}
	}
}
