package com.basic;

public class FindAreaOfTriangle {

	public static void main(String[] args) {
	System.out.println("Jay Shree Krishana...");
		int result=findAreaOfTriangle(10, 20);
		System.out.println(result);
	}
	
	public static int findAreaOfTriangle(int width,int height)
	{
		//Area = (width*height)/2
		
		return (width*height)/2;
	}
}
