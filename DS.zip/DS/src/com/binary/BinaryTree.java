package com.binary;

public class BinaryTree {

	 TreeNode root;
	// create Tree Node
	
	public static class TreeNode {
		int data;
		TreeNode left;
		TreeNode right;

		public TreeNode(int data) {
			this.data = data;
			this.left = null;
			this.right = null;
		}

		@Override
		public String toString() {
			return "TreeNode [data=" + data + ", left=" + left + ", right=" + right + "]";
		}
		
	}
public void display(TreeNode node)
{
	if(node!=null)
	{
		display(node.left);
		System.out.println(" "+node.data);
		display(node.right);
	}
	
}
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		BinaryTree bt=new BinaryTree();
		TreeNode first = new TreeNode(10);
		TreeNode second = new TreeNode(20);
		TreeNode third = new TreeNode(30);
		TreeNode fourth = new TreeNode(40);
		TreeNode fifth = new TreeNode(50);
		
		bt.root=first;
		first.left=second;
		first.right=third;
		second.left=fourth;
		second.right=fifth;
		
		
		
		
		System.out.println(bt.root);
		bt.display(bt.root);
		
	}

}
