package com.tree;

public class RepresentBinaryTree {
	
	private TreeNode root;
	
	
	public  class TreeNode
	{
		
		private int data;
		private TreeNode left;
		private TreeNode right;
		
		public TreeNode(int data) {
			
			this.data=data;
		}

		@Override
		public String toString() {
			return "TreeNode [data=" + data + ", left=" + left + ", right=" + right + "]";
		}
		
	}
	
	public  void createBinaryTree()
	{
		TreeNode first=new TreeNode(1);
		TreeNode second=new TreeNode(2);
		TreeNode third=new TreeNode(3);
		TreeNode fourth=new TreeNode(4);
		TreeNode fifth=new TreeNode(5);
		//TreeNode six=new TreeNode(6);
		
		root=first;
		first.left=second;
		first.right=third;
		second.left=fourth;
		second.right=fifth;
		
		
		
	}
	
	public static void main(String[] args) {
		System.out.println("Jay Shree Radhey...");
		
		RepresentBinaryTree representBinaryTree = new RepresentBinaryTree();
		representBinaryTree.createBinaryTree();
		
	}

}
