package com.pratice;

import java.util.Arrays;

public class ReverseArray {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		int arr[]={1,2,3,4,5,6,9,8};
		int n=arr.length;
		
		//reverse1(arr);
		//reverse2(arr);
		recursiveReverse(arr,0,n-1);
		System.out.println(Arrays.toString(arr));
	}

	private static void recursiveReverse(int[] arr,int start,int end) {
		
		if(start>end)return;
		int temp=arr[start];
		arr[start]=arr[end];
		arr[end]=temp;
		recursiveReverse(arr,start+1,end-1);
		
	}

	private static void reverse1(int[] arr) {
	
		int start=0,end=arr.length-1;
		while(start<end)
		{
			int temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
		}
		System.out.println(Arrays.toString(arr));
	}
	
	private static void reverse2(int[] arr) {
		int n=arr.length;
		for(int i=0;i<n/2;i++)
		{
			int temp=arr[i];
			arr[i]=arr[n-1-i];
			arr[n-1-i]=temp;
		}
		
		System.out.println(Arrays.toString(arr));
	}
	
	
}
