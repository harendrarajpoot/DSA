package com.queue;

import java.util.Arrays;

public class CircularQueueUsingArray {

	int maxSize = 5;
	int arr[] = new int[maxSize];
	int front = -1;
	int rear = -1;

	public void enqueue(int data)// 10,20,30,40,50
	{
		//
		if (front == (rear + 1) % maxSize)// f=0 ,
		{
			// failed if rear =4
			System.out.println("Overflow...");
			return;
		} else if (isEmpty()) {
			front++;// f==0
			arr[++rear] = data;// 10
		} else {
			rear = (rear + 1) % maxSize;
			arr[rear] = data;

		}
		// 10,20,30

	}

	public void dequeue() {
		if (isEmpty()) {
			System.out.println("Queue Alreday Empty...");
		} else if (front == rear) {
			front = -1;
			rear = -1;
			// rear=4;
		} else {
			front = (front + 1) % maxSize; // 1
		}
	}

	public boolean isEmpty() {
		if (front == -1 && rear == -1) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");
		CircularQueueUsingArray cq = new CircularQueueUsingArray();
		// for(int i=1;i<=5;i++)
		cq.enqueue(10);
		cq.enqueue(20);
		cq.enqueue(30);
		cq.enqueue(40);
		cq.enqueue(50);
		System.out.println(Arrays.toString(cq.arr));
		// cq.enqueue(60);
		cq.dequeue();
		cq.enqueue(60);
		System.out.println(Arrays.toString(cq.arr));

	}
}
