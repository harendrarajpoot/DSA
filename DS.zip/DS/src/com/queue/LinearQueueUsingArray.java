package com.queue;

import java.util.Arrays;

public class LinearQueueUsingArray {

	int front =-1;
	int rear =-1;
	int arr[]=new int[10];
	public void enqueue(int data)
	{
		if(rear==arr.length-1)
		{
			System.out.println("Overflow Queue...");
		}
		else
		{
			if(rear==-1 && front ==-1)
			{	front=0;
				rear=0;
				arr[rear]=data;
			}
			else
			{
				arr[++rear]=data;
			}
		}
	}
	
	public void dequeue()
	{
		if(front==-1 && rear==-1)
		{
			System.out.println("Empty Queue");
		}
		else
		{
		front++;
		}
	}
	
	public void display()
	{
		for(int i=front;i<=rear;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		LinearQueueUsingArray aq=new LinearQueueUsingArray();
		aq.dequeue();
		aq.enqueue(10);
		aq.enqueue(20);
		aq.enqueue(30);
		aq.enqueue(40);
		aq.enqueue(50);
		aq.enqueue(60);
		aq.enqueue(70);
		aq.enqueue(80);
		aq.enqueue(90);
		aq.enqueue(100);
		
		aq.display();
		aq.dequeue();
	    aq.display();
	    aq.enqueue(10);
	    
	}
}
