package com.queue;

public class LinearQueueUsingLinkList {

	private ListNode front;
	private ListNode rear;
	private int length;

	// create Node
	private static class ListNode {
		private int data;
		private ListNode next;

		public ListNode(int data) {
			this.data = data;
			this.next = null;
		}
	}

	public int length() {
		return length;
	}

	public boolean isEmpty() {
		return length == 0;
	}

	public void enqueue(int data) {
		ListNode newNode = new ListNode(data);
		if (isEmpty()) {
			front = newNode;
			rear = newNode;
		} else {
			rear.next = newNode;
		}
		rear = newNode;
		length++;
	}

	// 10 null-->20 null-->30 null
	public void dequeue() {
		if (isEmpty()) {
			System.out.println("Queue is already Empty");
			return;
		}
		front = front.next;
		length--;

	}

	public void display() {
		if (isEmpty()) {
			return;
		}
		ListNode temp = front;
		while (temp != null) {
			System.out.print(temp.data + "-->");
			temp = temp.next;
		}
		System.out.println("Null");
	}

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishana...");

		LinearQueueUsingLinkList q = new LinearQueueUsingLinkList();
		System.out.println(q.length());
		q.enqueue(10);
		q.enqueue(20);
		q.enqueue(30);
		q.enqueue(40);
		q.display();
		System.out.println(q.length());
		q.dequeue();
		System.out.println(q.length());
		q.display();
		q.dequeue();
		q.dequeue();
		q.dequeue();
		System.out.println(q.length());
		q.display();

	}
}
