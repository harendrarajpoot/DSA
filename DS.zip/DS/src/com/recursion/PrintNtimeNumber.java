package com.recursion;

public class PrintNtimeNumber {

	public static void method(int n)
	{
		if(n<1)
		{
			return;
		}
		System.out.println(n);
		method(n-1);
	}
	
	public static int fect(int n)
	{
		if(n==1)
		{
			return 1;
		}
		else
		{
			
			return n*fect(n-1);//5
		}
	}
	
	public static int sumOfNaturalNumber(int n)
	{
		//3+2+1
		if(n!=0)
		{
			return n+sumOfNaturalNumber(n-1);
		}
		else
		{
			return n;
		}
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Jay SHree Krishana...");
		//method(10000);
		System.out.println(fect(5));
		System.out.println(sumOfNaturalNumber(10));
	}
}

