package com.string;

public class RemoveVowels {

	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		String str="jave love you ";
		
		
		for (int i = 0; i < str.length()-1; i++) {
			
			char ch=str.charAt(i);
			
			if (ch=='A'||ch=='a'||ch=='E'||ch=='e'||ch=='I'||ch=='i'||ch=='o'||ch=='O'||ch=='U'||ch=='u') {
				//System.out.println(ch);
				continue;
				
			}
			System.out.print(ch);
		}
	}
}
