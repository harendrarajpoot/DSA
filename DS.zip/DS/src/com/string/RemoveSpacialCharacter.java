package com.string;

public class RemoveSpacialCharacter {
public static void main(String[] args) {
	
	System.out.println("Jay Shree Ram...");
	
	
	String str="st@#4a!^g%&8()*e";
	
	String repAll=str.replaceAll("[^a-zA-Z]", "");
	
	
	
	System.out.println(repAll);
}
}
