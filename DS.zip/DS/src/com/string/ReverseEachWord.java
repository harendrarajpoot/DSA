package com.string;

import java.util.Arrays;

public class ReverseEachWord {
public static void main(String[] args) {
	System.out.println("Jay Shree Krishana...");
	
	String str="Jay Shree Krishana";
	
	String words[]=str.split(" ");
	
	System.out.println(Arrays.toString(words));
	String output="";
	for(String word:words)
	{
		String revWord="";
		for (int i = word.length()-1;i>=0;i--) {
			
			revWord+=word.charAt(i);
		}
		output=output+revWord+" ";
	}
	
	System.out.println(output);
}
}
