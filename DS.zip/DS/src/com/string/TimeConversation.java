package com.string;

public class TimeConversation {
 public static void main(String[] args) {
	System.out.println("Jay Shree Krishna...");
	String str="07:05:45PM";
	
	String s="";
	if(str.substring(0, 2).equals("12") && str.contains("AM"))
	{
		
		
		
	}
}
}
