package com.string;

public class RemoveWhiteSpace {

	public static void main(String[] args) {
		System.out.println("Jay Shree Ram...");
		String str="ja va i s com pu ter pro gramm ing lang uage";
		
	String repAll=	str.replaceAll("\\s", "");
	System.out.println(repAll);
	}
}
