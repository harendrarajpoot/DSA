package com.string;

public class ReverseString {
	public static void main(String[] args) {
		System.out.println("Jay shree krishna...");
		String str = "Hello";
		reverseStringUsingToCharArrayMethod(str);
		System.out.println();
		reverseStringUsingStringLengthMethod(str);
		System.out.println();
		reverseStringUsingStringBufferMethod(str);
		reverseStringUsingStringBuilderMethod(str);
	}
// Approach 1
	public static void reverseStringUsingToCharArrayMethod(String str) {

		for (int i = str.toCharArray().length - 1; i >= 0; i--) {
			System.out.print(str.charAt(i));
		}

	}
	
	// Approach 2
	
	public static void reverseStringUsingStringLengthMethod(String str)
	{
		for (int i = str.length()-1; i >=0; i--) {
			
			System.out.print(str.charAt(i));
		}
	}
	// Approach 3
	public static void reverseStringUsingStringBufferMethod(String str)
	{
		StringBuffer sb=new StringBuffer(str);
		System.out.println(sb.reverse());
	}
	
	// Approach 4
	public static void reverseStringUsingStringBuilderMethod(String str)
	{
		StringBuilder sb=new StringBuilder();
		sb.append(str);
		sb.reverse();
		System.out.println(sb);
	}
}
