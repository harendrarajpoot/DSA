package com.string;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class FindDuplicateWord {
	
	public static void main(String[] args) {
		String str = "Java is a programming language and a platform. Java is a high level robust object-oriented AND secure programming language";// second
		
		// there are two way to find out duplicate words in given string.
		
		// split string by comma using split() method and it will return string array
		
		String words[]=str.split(" ");
		System.out.println(Arrays.toString(words));
		//1st Way
		
	/*	for(int i=0;i<words.length;i++)
		{
			int count =1;
			for(int j=i+1;j<words.length;j++)
			{
				if(words[i].equals(words[j]))
				{
					
					count++;
					// revisiting not repeated
					words[j]="0";
				}
			}
			if(count>1&& words[i]!="0")
				System.out.println(words[i]+"--->"+count);
		}*/
		
		
		// 2nd Way
		//Java is a programming language
		Map<String, Integer>map=new HashMap<>();
		int count=1;
		for (int i = 0; i < words.length; i++) {
			
			if(map.containsKey(words[i]))
			{
				map.put(words[i], map.get(words[i])+1);
			}
			else
			{
				map.put(words[i], count);
			}
		}
		
		System.out.println(map);
	}

}
