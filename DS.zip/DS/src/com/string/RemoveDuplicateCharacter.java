package com.string;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.IntStream;

public class RemoveDuplicateCharacter {
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishan...");
		String str = "programming";

		// Using java 8
		StringBuilder sb1 = new StringBuilder();
		IntStream distinct = str.chars().distinct();
		distinct.forEach(s -> System.out.print((char) s));

		// Using indexOf()
		System.out.println();
		StringBuilder sb2 = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			int idx = str.indexOf(ch, i + 1);
			if (idx == -1) {
				sb2.append(ch);
			}

		}
		System.out.println(sb2);
		// Using Character Array

		StringBuilder sb3 = new StringBuilder();
		char ch[] = str.toCharArray();

		for (int i = 0; i < ch.length; i++) {
			boolean flag = false;
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				sb3.append(ch[i]);
			}
		}
		
		System.out.println(sb3);

		// Using Set Interface
		
		StringBuilder sb4=new StringBuilder();
		Set<Character> set=new LinkedHashSet<>();
		for (int i = 0; i <= str.length()-1; i++) {
			set.add(str.charAt(i));
		}
		for (Character character : set) {
			sb4.append(character);
		}
		System.out.println(sb4);
	}

}
