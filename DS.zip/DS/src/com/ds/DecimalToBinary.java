package com.ds;

import java.util.Scanner;

public class DecimalToBinary {
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number...");
		int num=sc.nextInt();
		long sum=0;
		long mul=1;
		while(num!=0)
		{
			long rem=num%2;
			sum=sum+rem*mul;
			num=num/2;
			mul=mul*10;
		}
		System.out.println(sum);
	}

}
