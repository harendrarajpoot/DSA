package com.ds;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class BinaryToDecimal {
	
	public void method()
	{
		System.out.println("hello Method....");
		method1();
	}
	public void method1()
	{
		
		System.out.println("hello Method111111....");
	}
	public static void main(String[] args) {
		System.out.println("Jay Shree Krishna...");
		BinaryToDecimal b=new BinaryToDecimal();
		b.method();
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number...");
		int num=sc.nextInt();
		long sum=0;
		long mul=1;
		while(num!=0)
		{
			long rem=num%10;
			num=num/10;
			sum=sum+rem*mul;
			mul=mul*2;
		}
		System.out.println(sum);*/
		
	List<Integer> list=new LinkedList<>();
	list.add(10);
	list.add(20);
	list.add(30);
	list.add(40);
	list.add(50);
	list.add(60);
	list.add(70);
	list.add(80);
System.out.println(list);	
ArrayList<Integer> arrayList = new ArrayList<>();
arrayList.add(90);
arrayList.add(100);
arrayList.add(1);
System.out.println(arrayList);
arrayList.addAll(list);
System.out.println(arrayList);
		
		
	}
}
