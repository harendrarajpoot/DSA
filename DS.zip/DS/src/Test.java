import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Test {
	public static void main(String[] args) {

		String s = "Java is a programming language and a platform. Java is a high level robust object-oriented AND secure programming language";// second
																																					// most
																																					// repetitive
																																					// word
		String str = "abc#de#"; // The "#" represents as backspace. Write a
								// program is to print the new string without
								// "#" and immediate before character. Final
								// output would be �abd�
		
		String words[]=s.split(" ");
		System.out.println(Arrays.toString(words));
		
		Map<String, Integer>map=new HashMap<>();
		
		int count=1;
		for(String word:words)
		{
			
			if(map.containsKey(word))
			{
				map.put(word, map.get(word)+1);
			}
			else
			{
				map.put(word, count);
			}
		}
		
			System.out.println(map);
		
			
				for(String st:map.keySet())
				{
					if(map.get(st)>1)
					System.out.println(st);
				}
			
		/*
		 * char ch[]=s.toCharArray();
		 * 
		 * Map<Character, Integer>map=new HashMap<>(); int count=1; for (int i =
		 * 0; i < ch.length; i++) {
		 * 
		 * if(!map.containsKey(ch[i]))// { map.put(s.charAt(i), count);//1, }
		 * else { map.put(s.charAt(i),count+1 );
		 * 
		 * } }
		 * 
		 * System.out.println(map.toString());
		 */

	}

}
